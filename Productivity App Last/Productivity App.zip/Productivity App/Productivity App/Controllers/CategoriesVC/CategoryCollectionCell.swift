//
//  CategoryCollectionCell.swift
//  Productivity App
//
//  Created by Rahul Chopra on 18/01/18.
//  Copyright © 2018 Clicks Bazaar. All rights reserved.
//

import UIKit

class CategoryCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var lblHeader: UILabel!
    @IBOutlet weak var lblSubHeader: UILabel!
}
