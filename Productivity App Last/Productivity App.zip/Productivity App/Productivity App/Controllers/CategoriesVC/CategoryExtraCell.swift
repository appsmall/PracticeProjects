//
//  CategoryExtraCell.swift
//  Productivity App
//
//  Created by Rahul Chopra on 18/01/18.
//  Copyright © 2018 Clicks Bazaar. All rights reserved.
//

import UIKit

class CategoryExtraCell: UICollectionViewCell
{
    
    @IBOutlet weak var imgCell: UIImageView!
    
    
}
